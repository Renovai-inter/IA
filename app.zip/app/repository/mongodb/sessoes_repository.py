# Modelagem
# collection: sessoes
# {
#   '_id':              ObjectId(),          // deixa o Mongo gerar nativo — evita round-trip e já vem ordenável por tempo
#   'session_id':       'uuid-do-thread',    // == o mesmo valor passado como thread_id pro LangGraph (ChatRequest.session_id)
#   'usuario_id':       'uuid-do-usuario'    // FK lógica para usuarios.id (usar perfil_id quando nulo - é empresa)
#   'perfil_id':        'uuid-do-perfil',    // FK lógica pra perfis.id no Postgres
#   'status':           'ativa' | 'encerrada',
#   'iniciada_em':      datetime,
#   'atualizada_em':    datetime,            // timestamp do último turno — sem isso não dá pra saber sessão 'esquecida' vs. ativa de fato
#   'encerrada_em':     datetime | null,
#   'resumo':           'string' | null,     // resumo incremental, atualizado pelo Orquestrador a cada N turnos
#   'agentes_acionados': ['router_agent', 'material_estoque_agent'],  // ideal == GraphState.agentes_chamados acumulado
#   'mensagens': [
#     {
#       'role':      'usuario' | 'assistente',
#       'agente':    'material_estoque_agent' | null,  // qual especialista gerou; null pro turno do usuário
#       'content':   '...',
#       'timestamp': datetime,
#       'meta': {                             // opcional, pensado já pra Fase 5 (observabilidade)
#         'modelo':         'gemini-3.5-flash',
#         'tokens_entrada': 123,
#         'tokens_saida':   45,
#         'latencia_ms':    800
#       }
#     }
#   ]
# }

from pydantic import BaseModel
from datetime import datetime
from typing import Dict, List, Literal, Optional
from uuid import UUID

from pymongo import MongoClient

from app.repository.base import Repository


class Sessoes(BaseModel):
    _id: UUID
    session_id: UUID
    perfil_id: UUID
    usuario_id: UUID
    status: Literal['ativa', 'encerrada']
    data_inicio: datetime
    data_atualizacao: datetime
    data_encerramento: Optional[datetime]
    resumo: Optional[str]
    agentes_chamados: List[str] = []
    mensagens: List[Dict]


class SessoesRepository(Repository[Sessoes]):
    _mongo: MongoClient | None = None
    _col_sessoes = None
    _indexes_created = False
    _sessoes_ativas: dict = {}

    def _get_collection(self):
        if self._col_sessoes is not None:
            return self._col_sessoes

        self._col_sessoes = self._db['sessoes']

        if not self._indexes_created:
            self._col_sessoes.create_index('session_id')
            self._col_sessoes.create_index('iniciada_em')
            self._indexes_created = True

        return self._col_sessoes